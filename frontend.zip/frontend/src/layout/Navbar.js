import React from "react";
// import { Link } from "react-router-dom";
import { ChakraProvider,Button,Box,Text,Link,HStack } from '@chakra-ui/react'

export default function Navbar() {
  return (
    
    <div>
          <ChakraProvider>
      <Box width='100%' height='80px' bg='black' > <HStack>  <Text color='white' fontSize='26px' ml='47%'>Empower</Text>   
       <Button ml='38%' mt='20px'> <Link color='black'  href="/adduser">
            Add User
          </Link></Button></HStack></Box>
   
    </ChakraProvider>
 
    </div>
  );
}
